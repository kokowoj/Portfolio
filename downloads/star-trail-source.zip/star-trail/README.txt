STAR TRAIL — p5.js star cursor particle effect

Open index.html in a browser with an internet connection (p5.js is loaded from a CDN).
Move the mouse to generate the trail.

Source: Adapted from the creator's portfolio cursor script.
Original sketch: https://editor.p5js.org/kokowoj/sketches/PiJEPCazt

REUSE / PERMISSION NOTICE
A public download is provided for inspection and educational reference.
No license for copying into other projects is granted in this draft.
Contact the creator to request permission or check this project's future license.
This notice is a placeholder until the creator chooses a license.
